using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Security.Permissions;
using UnityEngine;
using TMPro;
using UnityEngine.Events;

namespace Mod
{
	public class ConfigurableExplosiveBehaviour: MonoBehaviour 
    {
	   void Awake()
	   {
       Explosion = gameObject.GetComponent<ExplosiveBehaviour>();
		   Rigidbody = gameObject.GetComponent<Rigidbody2D>();
		   PhysicalBehaviour = gameObject.GetComponent<PhysicalBehaviour>();
		   PhysicalBehaviour.ContextMenuOptions.Buttons.Add(new ContextMenuButton("SetExplosionRange", "Set Explosion Range", "Sets Explosion Range.", () => {
                DialogBox dialog = (DialogBox)null;
                dialog = DialogBoxManager.TextEntry("Enter the explosion range\n<color=green><size=26>Default: 10,Currently:"+CurrentExplosionRange+"</size></color>", "Number", new DialogButton("Apply", true, new UnityAction[1] {
                  (UnityAction)(() => {
                    float setrange;
                    if (float.TryParse(dialog.EnteredText, out setrange)) {
                      CurrentExplosionRange = setrange;
                    }
                  })
                }),
                  new DialogButton("Cancel", true, (UnityAction)(() => dialog.Close())));
            }));

            PhysicalBehaviour.ContextMenuOptions.Buttons.Add(new ContextMenuButton("SetImpactForceThreshold", "Set Impact Force Threshold", "Sets Impact Force Threshold.", () => {
                DialogBox dialog = (DialogBox)null;
                dialog = DialogBoxManager.TextEntry("Enter the impact force threshold\n<color=green><size=26>Default: 10,Currently:"+CurrentImpactForceThreshold+"</size></color>", "Number", new DialogButton("Apply", true, new UnityAction[1] {
                  (UnityAction)(() => {
                    float setrange;
                    if (float.TryParse(dialog.EnteredText, out setrange)) {
                      CurrentImpactForceThreshold = setrange;
                    }
                  })
                }),
                  new DialogButton("Cancel", true, (UnityAction)(() => dialog.Close())));
            }));

            PhysicalBehaviour.ContextMenuOptions.Buttons.Add(new ContextMenuButton("SetExplosionDelay", "Set Explosion Delay", "Sets Explosion Delay.", () => {
                DialogBox dialog = (DialogBox)null;
                dialog = DialogBoxManager.TextEntry("Enter the explosion delay\n<color=green><size=26>Default: 0,Currently:"+CurrentExplosionDelay+"</size></color>", "Number", new DialogButton("Apply", true, new UnityAction[1] {
                  (UnityAction)(() => {
                    float setrange;
                    if (float.TryParse(dialog.EnteredText, out setrange)) {
                      CurrentExplosionDelay = setrange;
                    }
                  })
                }),
                  new DialogButton("Cancel", true, (UnityAction)(() => dialog.Close())));
            }));

            PhysicalBehaviour.ContextMenuOptions.Buttons.Add(new ContextMenuButton("SetExplodeBurnThreshold", "Set Explode Burn Threshold", "Sets Explode Burn Threshold.", () => {
                DialogBox dialog = (DialogBox)null;
                dialog = DialogBoxManager.TextEntry("Enter the burn threshold\n<color=green><size=26>Default: 1,Currently:"+CurrentExplodeBurnProgressThreshold+"</size></color>", "Number", new DialogButton("Apply", true, new UnityAction[1] {
                  (UnityAction)(() => {
                    float setrange;
                    if (float.TryParse(dialog.EnteredText, out setrange)) {
                      CurrentExplodeBurnProgressThreshold = setrange;
                    }
                  })
                }),
                  new DialogButton("Cancel", true, (UnityAction)(() => dialog.Close())));
            }));

            PhysicalBehaviour.ContextMenuOptions.Buttons.Add(new ContextMenuButton("SetBurnPower", "Set Burn Power", "Sets Burn Power.", () => {
                DialogBox dialog = (DialogBox)null;
                dialog = DialogBoxManager.TextEntry("Enter the burn power\n<color=green><size=26>Default: 1,Currently:"+CurrentBurnPower+"</size></color>", "Number", new DialogButton("Apply", true, new UnityAction[1] {
                  (UnityAction)(() => {
                    float setrange;
                    if (float.TryParse(dialog.EnteredText, out setrange)) {
                      CurrentBurnPower = setrange;
                    }
                  })
                }),
                  new DialogButton("Cancel", true, (UnityAction)(() => dialog.Close())));
            }));

            PhysicalBehaviour.ContextMenuOptions.Buttons.Add(new ContextMenuButton("SetDismemberChance", "Set Dismember Chance", "Sets Dismember Chance.", () => {
                DialogBox dialog = (DialogBox)null;
                dialog = DialogBoxManager.TextEntry("Enter the dismember chance\n<color=green><size=26>Default: 0,Currently:"+CurrentDismemberChance+"</size></color>", "Number", new DialogButton("Apply", true, new UnityAction[1] {
                  (UnityAction)(() => {
                    float setrange;
                    if (float.TryParse(dialog.EnteredText, out setrange)) {
                      CurrentDismemberChance = setrange;
                    }
                  })
                }),
                  new DialogButton("Cancel", true, (UnityAction)(() => dialog.Close())));
            }));

            PhysicalBehaviour.ContextMenuOptions.Buttons.Add(new ContextMenuButton("SetShotExplodeChance", "Set Shot Explode Chance", "Sets Shot Explode Chance.", () => {
                DialogBox dialog = (DialogBox)null;
                dialog = DialogBoxManager.TextEntry("Enter the shot explode chance\n<color=green><size=26>Default: 1,Currently:"+CurrentShotExplodeChance+"</size></color>", "Number", new DialogButton("Apply", true, new UnityAction[1] {
                  (UnityAction)(() => {
                    float setrange;
                    if (float.TryParse(dialog.EnteredText, out setrange)) {
                      CurrentShotExplodeChance = setrange;
                    }
                  })
                }),
                  new DialogButton("Cancel", true, (UnityAction)(() => dialog.Close())));
            }));

            PhysicalBehaviour.ContextMenuOptions.Buttons.Add(new ContextMenuButton("SetShockwaveLiftForce", "Set Shockwave Lift Force", "Sets Shockwave Lift Force.", () => {
                DialogBox dialog = (DialogBox)null;
                dialog = DialogBoxManager.TextEntry("Enter the shockwave lift force\n<color=green><size=26>Default: 1,Currently:"+CurrentShockwaveLiftForce+"</size></color>", "Number", new DialogButton("Apply", true, new UnityAction[1] {
                  (UnityAction)(() => {
                    float setrange;
                    if (float.TryParse(dialog.EnteredText, out setrange)) {
                      CurrentShockwaveLiftForce = setrange;
                    }
                  })
                }),
                  new DialogButton("Cancel", true, (UnityAction)(() => dialog.Close())));
            }));

             PhysicalBehaviour.ContextMenuOptions.Buttons.Add(new ContextMenuButton("SetFragmentForce", "Set Fragment Force", "Sets Fragment Force.", () => {
                DialogBox dialog = (DialogBox)null;
                dialog = DialogBoxManager.TextEntry("Enter the fragment force\n<color=green><size=26>Default: 1,Currently:"+CurrentFragmentForce+"</size></color>", "Number", new DialogButton("Apply", true, new UnityAction[1] {
                  (UnityAction)(() => {
                    float setrange;
                    if (float.TryParse(dialog.EnteredText, out setrange)) {
                      CurrentFragmentForce = setrange;
                    }
                  })
                }),
                  new DialogButton("Cancel", true, (UnityAction)(() => dialog.Close())));
            }));

            gameObject.GetComponent<PhysicalBehaviour>().ContextMenuOptions.Buttons.Add(new ContextMenuButton("ToggleDestroyOnExplode", delegate()
            {
            if (!DestroyOnExplodeCheck)
            {
	          	return "Destroy On Explode: False";
            }
              return "Destroy On Explode: True";
            }, "Toggle if the explosive destroys itself on explosion", new UnityAction[]
            {
            delegate()
            {
                DestroyOnExplodeCheck = !DestroyOnExplodeCheck;
                if(!DestroyOnExplodeCheck)
                {
                    Explosion.DestroyOnExplode = false;
                    PhysicalBehaviour.Properties.Flammability = 0f;
                }
                else
                {
                    Explosion.DestroyOnExplode = true;
                    PhysicalBehaviour.Properties.Flammability = 0.5f;
                }
            }
        }));
	   }
	   void FixedUpdate()
	   {
        Explosion.Range = CurrentExplosionRange;
        Explosion.ImpactForceThreshold = CurrentImpactForceThreshold;
        Explosion.Delay = CurrentExplosionDelay;
        Explosion.ExplodeBurnProgressThreshold = CurrentExplodeBurnProgressThreshold;
        Explosion.BurnPower = CurrentBurnPower;
        Explosion.DismemberChance = CurrentDismemberChance;
        Explosion.ShotExplodeChance = CurrentShotExplodeChance;
        Explosion.ShockwaveLiftForce = CurrentShockwaveLiftForce;
        Explosion.FragmentForce = CurrentFragmentForce;
	   }
       [SkipSerialisation]
	     public PhysicalBehaviour PhysicalBehaviour;
       [SkipSerialisation]
	     public Rigidbody2D Rigidbody;
       [SkipSerialisation]
       public ExplosiveBehaviour Explosion;
       public bool DestroyOnExplodeCheck = true;
       public float CurrentExplodeBurnProgressThreshold = 1f;
       public float CurrentExplosionDelay = 0f;
       public float CurrentImpactForceThreshold = 10f;
       public float CurrentExplosionRange = 10f;
       public float CurrentBurnPower = 1f;
       public float CurrentDismemberChance = 0f;
       public float CurrentShotExplodeChance = 1f;
       public float CurrentShockwaveLiftForce = 1f;
       public float CurrentFragmentForce = 1f;
    }
}