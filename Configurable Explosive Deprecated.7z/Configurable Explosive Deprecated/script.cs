using UnityEngine;
using UnityEngine.Events;

// Hello! Feel free to use some of Pumpkin's (lmao) code to learn or create a new mod, but please don't completely copy it!

namespace Mod
{
    public class Mod
    {
        public static void Main()
        {
            ModAPI.Register(
                new Modification()
                {
                    OriginalItem = ModAPI.FindSpawnable("Dynamite"),
                    NameOverride = "Configurable Explosive",
                    DescriptionOverride = "An explosive that you can configure to your liking!",
                    CategoryOverride = ModAPI.FindCategory("Explosives"),
                    ThumbnailOverride = ModAPI.LoadSprite("ConfigExplosiveView.png"),
                    AfterSpawn = (Instance) =>
                    {
                        Instance.GetComponent<SpriteRenderer>().sprite = ModAPI.LoadSprite("configExplosive.png");
                        if(Instance.GetComponent<ConfigurableExplosiveBehaviour>() == null)
				     	{
			     			Instance.AddComponent(typeof (ConfigurableExplosiveBehaviour));
				     	}
                        Instance.FixColliders();
                    }
                }
            );
        }
    }
}